﻿using AutoIt;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.IE;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Support.UI;
using SSO.Common;
using SSO.Configuration;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SSO.PageObject
{
    public class NonMemberPO
    {
        public IWebDriver driver;
        public IWait<OpenQA.Selenium.IWebDriver> iWait;
        Config cf = new Config();

        int searchTryCnt = 0;
        string UserEmailAddress, Password, forename, surname, MembershipNumber, MembershipNumberDarwin, registeredEmailAddress, validationEmailErrorMessage, wrongPassword, validationPasswordErrorMessage, username, password, driverName, driverPath, ActualInvalidEmailValMsg, ExpectedInvalidEmailValMsg, ActualIncorrectCodeValMsg, ExpectedIncorrectCodeValMsg;
        int screenHeight, screenWidth;
        

        #region Selector
        By MktDropDownContact = By.CssSelector("div#navTabGroupDiv>span.navBarTopLevelItem>span#TabSFA>a.navTabButtonLink");
        By Contacts = By.XPath("//*[@id='nav_conts']/span[2]");
        By loginLnk = By.CssSelector("h3#ssoLogin");
        By loginLink = By.LinkText("Please log in");
        By registerLnk = By.Id("rhRegisterLink");
        By loginUsingEmailAddressBtn = By.CssSelector("button#SignUpWithLogonEmailExchange");
        By emailAddressTxtbox = By.CssSelector("input#email.textInput");
        By verificationBtn = By.CssSelector("button#email_ver_but_send");
        By verificationCodeTxtbox = By.CssSelector("input#email_ver_input");
        By verifyBtn = By.Id("email_ver_but_verify");
        By continueBtn = By.Id("continue");
        By newPasswordTxtbox = By.CssSelector("input#newPassword");
        By confirmPasswordTxtbox = By.CssSelector("input#reenterPassword");
        By titleDd = By.CssSelector("Select#extension_Title");
        By forenameTxtbox = By.CssSelector("input#givenname");
        By surnameTxtbox = By.CssSelector("input#surname");
        By marketingConsent = By.CssSelector("input#extension_ConsentToMarketing_Yes");
        By myAccountLnk = By.LinkText("Your account");
        By myIETlnk = By.LinkText("My IET");
        By pleaseLoginWithSSOBtn = By.CssSelector("button.login");
        By myDetailsLnk = By.LinkText("MyDetails");
        By membershipNumber = By.XPath("//*[@id='personalEmploymentBox']/div[@class='innerDetailsPadding']/strong[2]");
        By membershipNumberTxtbox = By.CssSelector("input#extension_MembershipNumber");
        By membershipNumberDarwin = By.Id("H#H#IEE_D1");
        By darwinUserTxtbox = By.Id("userid");
        By darwinPassTxtbox = By.Id("pwd");
        By darwinSignInBtn = By.ClassName("psloginbutton");
        By customerCRMLnk = By.LinkText("Customers CRM");
        By frameCRM = By.XPath("//frame[@name ='TargetContent']");
        By searchPersonLink = By.LinkText("Search Person");
        By membershipTxtbox = By.XPath("//*[@id='RB_FLT_CRIT_WRK_RA_VALUE$0']");
        By searchTextbox = By.CssSelector("input#PB_FILTER");
        By shiftRightArrowLnk = By.Id("MAINTAB#_RIGHT");
        By custGrpLnk = By.Id("tab14");
        By memWebAccessDw = By.XPath("//tr[2]/td[@class='PSLEVEL1GRIDODDROW']/span");
        By optedIntoEAndTMagDw = By.XPath("//tr[3]/td[@class='PSLEVEL1GRIDEVENROW']/span");
        By staffMemberDw = By.XPath("//tr[4]/td[@class='PSLEVEL1GRIDODDROW']/span");
        By memberDw = By.XPath("//tr[6]/td[@class='PSLEVEL1GRIDODDROW']/span");
        By volunteerDw = By.XPath("//tr[5]/td[@class='PSLEVEL1GRIDEVENROW']/span");
        By ukDw = By.XPath("//tr[7]/td[@class='PSLEVEL1GRIDEVENROW'][4]/span");
        By deleteVolDw = By.Id("IEE_PERS_CGRP_V$delete$3$$0");
        By firstnameTxtbox = By.XPath("//*[@id='BO_NAME_FIRST_NAME$0']");
        By lastnameTxtbox = By.XPath("//*[@id='BO_NAME_LAST_NAME$0']");
        By cancelBtn = By.Id("cancel");
        By AccountCreatedLbl = By.CssSelector("h4.iet-h5");
        By validationLbl = By.CssSelector("div#claimVerificationServerError");
        By validationPasswordLbl = By.CssSelector("div.error.itemLevel.show>p");
        By searchTxtboxSilverbear = By.XPath("//*[@id='SearchNode']/a");
        By searchLblSilverbear = By.CssSelector("label#findHintText");
        By frame0 = By.Id("contentIFrame0");
        By frame1 = By.Id("contentIFrame1");
        By searchGrid = By.CssSelector("table#gridBodyTable>tbody");
        By loadingSB = By.CssSelector("span#LoadingImageLabel");
        By newContactHeader = By.CssSelector("span#TabNode_tab0Tab-main>a>span>span");
        By firstName = By.Id("First Name_label");
        By lastName = By.Id("Last Name_label");
        By firstNameLbl = By.Id("First Name_label");
        By lastNameLbl = By.Id("Last Name_label");
        By facebookLink = By.Id("FacebookOAuth");
        By emailFacebookTxtbox = By.CssSelector("input#email");
        By passwordFacebookTxtbox = By.CssSelector("input#pass");
        By loginFacebookBtn = By.Id("loginbutton");
        By validationErrorMessage = By.CssSelector("div.error.itemLevel.show>p");
        By validationMsgIncorrectCode = By.CssSelector("div#email_fail_retry");
        By yopmailSearchTxtbox = By.CssSelector("input#login.scpt");
        By yopmailFrame = By.Id("ifmail");
        By yopmailPassword = By.Id("mailmillieu");
        By appStatusDd = By.Id("IEE_MEMBER_APP_IEE_APPL_STATUS$0");
        By memAppTab = By.CssSelector("a#tab12");
        By processingImg = By.CssSelector("img.PSPROCESSING");
        By saveBtn = By.Id("#ICSave");
        #endregion

        public NonMemberPO(IWebDriver driver, IWait<OpenQA.Selenium.IWebDriver> iWait)
        {
            this.driver = driver;
            this.iWait = iWait;
        }

        public void clickOnPleaseLoginLink()
        {
            //Helper.IsJqueryActive(driver);
            Helper.IsJavaScriptActive(driver);
            //Thread.Sleep(5000);            
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(loginLink));
            driver.FindElement(loginLink).Click();
        }

        public void clickOnRegisterLink()
        {
            Thread.Sleep(5000);
            Helper.IsJavaScriptActive(driver);
            Helper.IsJqueryActive(driver);
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(registerLnk));
            driver.FindElement(registerLnk).Click();
        }

        public void clickOnLoginUsingEmailAddressButton()
        {
            Thread.Sleep(2000);
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(loginUsingEmailAddressBtn));
            driver.FindElement(loginUsingEmailAddressBtn).Click();
        }

        public void enterEmailAddress()
        {
            UserEmailAddress = "AutoNonMember" + Helper.GenerateRandomGuid(5) + "@yopmail.com";
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(emailAddressTxtbox));
            driver.FindElement(emailAddressTxtbox).Clear();
            driver.FindElement(emailAddressTxtbox).SendKeys(UserEmailAddress);
        }

        public void enterEmailAddressForForgotPassword()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(emailAddressTxtbox));
            driver.FindElement(emailAddressTxtbox).SendKeys(UserEmailAddress);
        }

        public void clickOnSendVerificationBtn()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(verificationBtn));
            driver.FindElement(verificationBtn).Click();
            Thread.Sleep(3000);
        }

        public void NavigateYopMail()
        {
            Helper.OpenNewTab(driver);

            driver.SwitchTo().Window(driver.WindowHandles.Last());
            String appURL = cf.readingXMLFile("SSO", "Yopmail", "startURL", "Config.xml");

            //string appURL = "http://www.yopmail.com/en/";

            driver.Navigate().GoToUrl(appURL);

            driver.Manage().Window.Maximize();
        }

        public string getPasswordFromMail()
        {
            Thread.Sleep(5000);

            driver.FindElement(yopmailSearchTxtbox).Clear();

            driver.FindElement(yopmailSearchTxtbox).SendKeys(UserEmailAddress);

            Thread.Sleep(3000);

            driver.FindElement(yopmailSearchTxtbox).SendKeys(OpenQA.Selenium.Keys.Enter);

            WebDriverWait wait = new WebDriverWait(driver, new TimeSpan(0, 2, 30));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(yopmailFrame));

            driver.SwitchTo().Frame(driver.FindElement(yopmailFrame));

            Thread.Sleep(3000);

            string[] passwordText = driver.FindElement(yopmailPassword).Text.Split(':');

            string finalPassword = passwordText[1].Substring(1, 6);

            return finalPassword;

        }

        public string getPasswordFromMailForRegisteredUser()
        {
            Thread.Sleep(5000);

            driver.FindElement(yopmailSearchTxtbox).SendKeys(cf.readingXMLFile("SSO", "NonMember", "EmailAddress", "Config.xml"));

            Thread.Sleep(3000);

            driver.FindElement(yopmailSearchTxtbox).SendKeys(OpenQA.Selenium.Keys.Enter);

            WebDriverWait wait = new WebDriverWait(driver, new TimeSpan(0, 2, 30));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(yopmailFrame));

            driver.SwitchTo().Frame(driver.FindElement(yopmailFrame));
            //driver.SwitchTo().Frame(mailFrame);

            Thread.Sleep(3000);

            //driver.FindElement(By.Id("mailmillieu"));

            string[] passwordText = driver.FindElement(yopmailPassword).Text.Split(':');

            string Password = passwordText[1].Substring(1, 6);

            return Password;
        }

        public void enterVerificationCodeForRegisteredUser()
        {
            string Password = getPasswordFromMailForRegisteredUser();
            driver.SwitchTo().Window(driver.WindowHandles.First());
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(verificationCodeTxtbox));
            driver.FindElement(verificationCodeTxtbox).SendKeys(Password);
        }

        public void enterVerificationCode()
        {
            string finalPassword = getPasswordFromMail();
            driver.SwitchTo().Window(driver.WindowHandles.First());
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(verificationCodeTxtbox));
            driver.FindElement(verificationCodeTxtbox).Clear();
            driver.FindElement(verificationCodeTxtbox).SendKeys(finalPassword);

        }

        public void enterVerificationCodeForRegistration()
        {
            string finalPassword = getPasswordFromMail();
            IList tabs = driver.WindowHandles;
            driver.SwitchTo().Window((string)tabs[1]);
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(verificationCodeTxtbox));
            driver.FindElement(verificationCodeTxtbox).SendKeys(finalPassword);
        }

        public void enterIncorectVerificationCode()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(verificationCodeTxtbox));
            driver.FindElement(verificationCodeTxtbox).SendKeys("456789");
        }
        public void clickOnVerifyBtn()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(verifyBtn));
            driver.FindElement(verifyBtn).Click();
        }

        public void clickOnContinueBtn()
        {
            Helper.IsJavaScriptActive(driver);
            Helper.IsJqueryActive(driver);
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(continueBtn));
            driver.FindElement(continueBtn).Click();
        }

        public void enterNewPassword()
        {
            Password = "Password@12" + Helper.GenerateRandomGuid(5);
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(newPasswordTxtbox));
            driver.FindElement(newPasswordTxtbox).Clear();
            driver.FindElement(newPasswordTxtbox).SendKeys(Password);
        }

        public void confirmPassword()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(confirmPasswordTxtbox));
            driver.FindElement(confirmPasswordTxtbox).Clear();
            driver.FindElement(confirmPasswordTxtbox).SendKeys(Password);
        }

        public void selectTitle(string title)
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(titleDd));
            SelectElement Title = new SelectElement(driver.FindElement(titleDd));
            Title.SelectByText(title);
            //Title.SelectByText("Miss");
        }

        public void addForename()
        {
            forename = "Autoforename" + Helper.GenerateRandomGuid(5);
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(forenameTxtbox));
            driver.FindElement(forenameTxtbox).SendKeys(forename);
        }

        public void addSurname()
        {
            surname = "AutoSurname" + Helper.GenerateRandomGuid(5);
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(surnameTxtbox));
            driver.FindElement(surnameTxtbox).SendKeys(surname);
        }

        public void acceptMarketingConsent()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(marketingConsent));
            driver.FindElement(marketingConsent).Click();
        }

        public void getMembershipNumber()
        {
            Thread.Sleep(4000);
            Helper.IsJqueryActive(driver);
            Helper.IsJavaScriptActive(driver);
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(myAccountLnk));
            Helper.MoveToElement(driver, driver.FindElement(myAccountLnk));
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(myIETlnk));
            driver.FindElement(myIETlnk).Click();
            //iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(pleaseLoginWithSSOBtn));
            //driver.FindElement(pleaseLoginWithSSOBtn).Click();            
            Helper.IsJavaScriptActive(driver);
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(myDetailsLnk));
            Helper.MoveToElement(driver, driver.FindElement(myDetailsLnk));
            Thread.Sleep(2000);
            driver.FindElement(myDetailsLnk).Click();
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(membershipNumber));
            MembershipNumber = driver.FindElement(membershipNumber).Text;
            //cf.writingIntoXML("SSO", "NonMember", "MembershipNumber", MembershipNumber, "TestData.xml");

        }

        public void clickOnSaveButton()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(saveBtn));
            driver.FindElement(saveBtn).Click();
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(processingImg));

            Helper.IsJavaScriptActive(driver);
        }

        public void navigateToMemAppTab()
        {
            Helper.IsJavaScriptActive(driver);
            //Helper.IsJqueryActive(driver);

            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(processingImg));
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(memAppTab));
            driver.FindElement(memAppTab).Click();
        }

        public void selectAppStatus()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(appStatusDd));
            SelectElement appStatus = new SelectElement(driver.FindElement(appStatusDd));
            appStatus.SelectByText("Elected");
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(processingImg));
        }

        public void saveMembershipNumberForMemberUser()
        {
            //iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(membershipNumberDarwin));
            MembershipNumber = driver.FindElement(membershipNumberDarwin).Text;
            Thread.Sleep(2000);

            if (MembershipNumber == "")
            {
                //navigateToMemAppTab();
                selectAppStatus();
                clickOnSaveButton();

                iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(membershipNumberDarwin));
                MembershipNumberDarwin = driver.FindElement(membershipNumberDarwin).Text;
            }

            else
            {
                iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(membershipNumberDarwin));
                MembershipNumberDarwin = driver.FindElement(membershipNumberDarwin).Text;
            }

            driver.SwitchTo().Window(driver.WindowHandles.First());
        }

        public void enterMemNumberForMemberUser()
        {
            Helper.IsJavaScriptActive(driver);
            Helper.IsJqueryActive(driver);

            Thread.Sleep(2000);

            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(membershipNumberTxtbox));
            driver.FindElement(membershipNumberTxtbox).SendKeys(MembershipNumberDarwin);
        }

        public void navigateToDarwin()
        {
            Helper.OpenNewTab(driver);

            driver.SwitchTo().Window(driver.WindowHandles.Last());

            string appURL = cf.readingXMLFile("SSO", "Darwin", "startURL", "Config.xml");

            driver.Navigate().GoToUrl(appURL);

            string username = cf.readingXMLFile("SSO", "Darwin", "Username", "Config.xml");

            string password = cf.readingXMLFile("SSO", "Darwin", "Password", "Config.xml");

            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(darwinUserTxtbox));
            driver.FindElement(darwinUserTxtbox).SendKeys(username);

            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(darwinPassTxtbox));
            driver.FindElement(darwinPassTxtbox).SendKeys(password);

            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(darwinSignInBtn));
            driver.FindElement(darwinSignInBtn).Click();

        }

        public void navigateToCustomerCRM()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(customerCRMLnk));
            driver.FindElement(customerCRMLnk).Click();
        }

        public void clickOnSearchPersonLinkInDarwin()
        {
            driver.SwitchTo().Frame(driver.FindElement(frameCRM));

            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(searchPersonLink));
            driver.FindElement(searchPersonLink).Click();
        }

        public void enterMemberShipNumberInSearchbox()
        {
            driver.SwitchTo().Frame(driver.FindElement(frameCRM));

            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(membershipTxtbox));
            driver.FindElement(membershipTxtbox).SendKeys(MembershipNumber);
        }

        public void enterMemberShipNumberInSearchboxForStaffUser()
        {
            driver.SwitchTo().Frame(driver.FindElement(frameCRM));

            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(membershipTxtbox));
            driver.FindElement(membershipTxtbox).SendKeys(cf.readingXMLFile("SSO", "Admin Portal", "StaffMembershipNumber", "Config.xml"));
        }

        public void enterMembershipNumberInSearchboxForStaffAndVolUser()
        {
            driver.SwitchTo().Frame(driver.FindElement(frameCRM));

            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(membershipTxtbox));
            driver.FindElement(membershipTxtbox).SendKeys(cf.readingXMLFile("SSO", "Admin Portal", "StaffAndVolMemNum", "Config.xml"));
        }
        public void clickOnSearch()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(searchTextbox));
            driver.FindElement(searchTextbox).Click();

        }

        public void naivgateToCustGrp()
        {
            //driver.SwitchTo().Window(driver.WindowHandles.Last());

            //iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(processingImg));
            //driver.SwitchTo().Frame(driver.FindElement(By.Id("CalFrame")));
            //Actions action = new Actions(driver);
            //action.MoveToElement(driver.FindElement(shiftRightArrowLnk)).Click().Perform();
            //driver.FindElement(By.ClassName("PSPAGECONTAINER")).Click();
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(shiftRightArrowLnk));
            driver.FindElement(shiftRightArrowLnk).Click();
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(processingImg));
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(custGrpLnk));
            driver.FindElement(custGrpLnk).Click();

        }

        public void verifyCustGrps()
        {
            String Actual, Expected;
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(memWebAccessDw));
            Actual = driver.FindElement(memWebAccessDw).Text;
            Expected = cf.readingXMLFile("SSO", "Darwin", "Mem", "Config.xml");
            Assert.AreEqual(Expected, Actual);

            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(optedIntoEAndTMagDw));
            Actual = driver.FindElement(optedIntoEAndTMagDw).Text;
            Expected = "Opted into E&T Magazine";
            Assert.AreEqual(Expected, Actual);

            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(staffMemberDw));
            Actual = driver.FindElement(staffMemberDw).Text;
            Expected = cf.readingXMLFile("SSO", "Darwin", "Staff Member", "Config.xml");
            Assert.AreEqual(Expected, Actual);

            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(volunteerDw));
            Actual = driver.FindElement(volunteerDw).Text;
            Expected = cf.readingXMLFile("SSO", "Darwin", "Volunteer", "Config.xml");
            Assert.AreEqual(Expected, Actual);

            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(memberDw));
            Actual = driver.FindElement(memberDw).Text;
            Expected = cf.readingXMLFile("SSO", "Darwin", "Member", "Config.xml");
            Assert.AreEqual(Expected, Actual);

            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(ukDw));
            Actual = driver.FindElement(ukDw).Text;
            Expected = cf.readingXMLFile("SSO", "Darwin", "UK", "Config.xml");
            Assert.AreEqual(Expected, Actual);


        }

        public void removeVolunteerCustGrp()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(deleteVolDw));
            driver.FindElement(deleteVolDw).Click();

            driver.SwitchTo().Alert().Accept();
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(processingImg));
        }


        public void verifyFirstNameAndLastName()
        {
            //driver.SwitchTo().Frame(driver.FindElement(frameCRM));         

            string firstname = driver.FindElement(firstnameTxtbox).GetAttribute("value");
           
            Assert.AreEqual(forename, firstname);

            string lastname = driver.FindElement(lastnameTxtbox).GetAttribute("value");
            Assert.AreEqual(surname, lastname);
        }

        public void clickOnCancel()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(cancelBtn));
            Thread.Sleep(5000);
            //Helper.IsJavaScriptActive(driver);
            //Helper.IsJqueryActive(driver);
            driver.FindElement(cancelBtn).Click();
            Helper.IsJavaScriptActive(driver);
            Helper.IsJqueryActive(driver);
            Thread.Sleep(3000);
        }

        public void VerifyAccountCreated()
        {
            Helper.IsJavaScriptActive(driver);
            Helper.IsJqueryActive(driver);

            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(AccountCreatedLbl));
            string AccountLabelHeader = driver.FindElement(AccountCreatedLbl).Text;
            string AccountLabel = cf.readingXMLFile("SSO", "NonMember", "AccountVerification", "Config.xml");
            Assert.AreEqual(AccountLabel, AccountLabelHeader);
        }

        public void enterInvalidEmail()
        {
            Helper.IsJavaScriptActive(driver);
            Helper.IsJqueryActive(driver);
            //Thread.Sleep(5000);
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(emailAddressTxtbox));
            driver.FindElement(emailAddressTxtbox).Clear();
            driver.FindElement(emailAddressTxtbox).SendKeys(cf.readingXMLFile("SSO", "Login", "InvalidEmail", "Config.xml"));
            //driver.FindElement(signInTxtbox).Clear();
        }

        public void EnterAlreadyRegisteredEmailAddress()
        {
            registeredEmailAddress = cf.readingXMLFile("SSO", "NonMember", "EmailAddress", "Config.xml");
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(emailAddressTxtbox));
            driver.FindElement(emailAddressTxtbox).SendKeys(registeredEmailAddress);
        }

        public void VerifyValidationErrorMessage()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(validationLbl));
            string ValidationErrorMsg = driver.FindElement(validationLbl).Text;
            validationEmailErrorMessage = cf.readingXMLFile("SSO", "NonMember", "ValidationErrorMessageEmail", "Config.xml");
            Assert.AreEqual(validationEmailErrorMessage, ValidationErrorMsg);
        }

        public void enterWrongPassword()
        {
            Helper.IsJavaScriptActive(driver);
            Helper.IsJqueryActive(driver);

            wrongPassword = "123456";
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(newPasswordTxtbox));
            driver.FindElement(newPasswordTxtbox).SendKeys(wrongPassword);
        }

        public void enterConfirmWrongPassword()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(confirmPasswordTxtbox));
            driver.FindElement(confirmPasswordTxtbox).SendKeys(wrongPassword);
        }

        public void verifyValidationMessageForPassword()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(validationPasswordLbl));
            string ValidationErrorMsg = driver.FindElement(validationPasswordLbl).Text;
            validationPasswordErrorMessage = cf.readingXMLFile("SSO", "NonMember", "ValidationErrorMessagePassword", "Config.xml");
            Assert.AreEqual(validationPasswordErrorMessage, ValidationErrorMsg);
        }

        public void navigateToSilverbear()
        {
            //Helper.OpenNewTab(driver);

            InternetExplorerOptions options = new InternetExplorerOptions();
            options.EnsureCleanSession = true;
            options.EnableNativeEvents = true;
            options.IgnoreZoomLevel = true;
            options.IntroduceInstabilityByIgnoringProtectedModeSettings = true;
            options.PageLoadStrategy = PageLoadStrategy.Eager;


            //options.AcceptInsecureCertificates = true;
            string baseDir = AppDomain.CurrentDomain.BaseDirectory;


            driverName = "webdriver.ie.driver"; // Driver name for Chrome

            driverPath = baseDir + "/IEDriverServer.exe"; // Path for ChromeDriver

            driver = new InternetExplorerDriver(options);
            screenHeight = Helper.GetScreenHeight(driver);

            screenWidth = Helper.GetScreenWidth(driver);

            Helper.SetWindowPosition(driver, 0, 0);

            Helper.SetWindowSize(driver, screenWidth, screenHeight);

            driver.SwitchTo().Window(driver.WindowHandles.Last());

            string appURL = cf.readingXMLFile("SSO", "Silverbear", "startURL", "Config.xml");

            driver.Navigate().GoToUrl(appURL);

            //if (driver.Url.Contains("https")) driver.Navigate().GoToUrl("javascript:document.getElementById('moreInformationDropdownLink').click()");

            //if (driver.Url.Contains("https")) driver.Navigate().GoToUrl("javascript:document.getElementById('overridelink').click()");

            driver.Navigate().GoToUrl("javascript:document.getElementById('overridelink').click()");

            Thread.Sleep(2000);

            username = cf.readingXMLFile("SSO", "Silverbear", "Username", "Config.xml");

            password = cf.readingXMLFile("SSO", "Silverbear", "Password", "Config.xml");

            AutoItX.WinWaitActive("Windows Security");
            AutoItX.Send("dev\\" + username);
            AutoItX.Send("{TAB}");
            Thread.Sleep(2000);
            AutoItX.Send(password);
            //AutoItX.Send("{!}");
            //Thread.Sleep(2000);
            AutoItX.Send("{TAB}");
            AutoItX.Send("{TAB}");
            AutoItX.Send("{ENTER}");
        }

        public void searchRecordInSilverbear()
        {
            Thread.Sleep(25000);

            Helper.IsJavaScriptActive(driver);
            Helper.IsJqueryActive(driver);

            Actions action = new Actions(driver);
            //iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(searchTxtboxSilverbear));
            Thread.Sleep(15000);

            action.MoveToElement(driver.FindElement(searchTxtboxSilverbear)).Click().Perform();

            //action.MoveToElement(driver.FindElement(searchTxtboxSilverbear)).Build().Perform();
            //action.MoveToElement(driver.FindElement(By.CssSelector("label#findHintText"))).Click().Perform(); //final working
            //iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id("search")));
            //action.MoveToElement(driver.FindElement(By.Id("search"))).Click().SendKeys("1234").Build().Perform();

            //action.MoveToElement(driver.FindElement(By.CssSelector("label#findHintText"))).SendKeys("234").SendKeys(Keys.Enter).Build().Perform();
            Thread.Sleep(2000);

            Thread.Sleep(5000);
            //action.MoveToElement(driver.FindElement(By.CssSelector("input#search"))).SendKeys("1234");         


            Thread.Sleep(3000);
            driver.FindElement(MktDropDownContact).Click();
            driver.FindElement(Contacts).Click();

            Thread.Sleep(10000);

        }
        public void searchUser()
        {
            Thread.Sleep(800000);
            driver.SwitchTo().Frame(driver.FindElement(By.Id("contentIFrame0")));

            driver.FindElement(By.CssSelector("input#crmGrid_findCriteria")).SendKeys(MembershipNumber);
            driver.FindElement(By.CssSelector("input#crmGrid_findCriteria")).SendKeys(Keys.Enter);

        }

        public void searchUserForMember()
        {
            Thread.Sleep(2000);
            //Thread.Sleep(800000);
            driver.SwitchTo().Frame(driver.FindElement(By.Id("contentIFrame0")));

            driver.FindElement(By.CssSelector("input#crmGrid_findCriteria")).SendKeys("1100797091");
            driver.FindElement(By.CssSelector("input#crmGrid_findCriteria")).SendKeys(Keys.Enter);
        }


        public void searchRecordInSilverbearByEmailAddress()
        {
            Thread.Sleep(55000);

            Helper.IsJavaScriptActive(driver);
            Helper.IsJqueryActive(driver);

            Actions action = new Actions(driver);
            //iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(searchTxtboxSilverbear));
            Thread.Sleep(15000);

            action.MoveToElement(driver.FindElement(searchTxtboxSilverbear)).Click().Perform();

            //action.MoveToElement(driver.FindElement(searchTxtboxSilverbear)).Build().Perform();
            //action.MoveToElement(driver.FindElement(By.CssSelector("label#findHintText"))).Click().Perform(); //final working
            //iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.Id("search")));
            //action.MoveToElement(driver.FindElement(By.Id("search"))).Click().SendKeys("1234").Build().Perform();

            //action.MoveToElement(driver.FindElement(By.CssSelector("label#findHintText"))).SendKeys("234").SendKeys(Keys.Enter).Build().Perform();
            Thread.Sleep(2000);

            Thread.Sleep(5000);
            //action.MoveToElement(driver.FindElement(By.CssSelector("input#search"))).SendKeys("1234");         


            Thread.Sleep(3000);
            driver.FindElement(MktDropDownContact).Click();
            driver.FindElement(Contacts).Click();


            Thread.Sleep(300000);
            driver.SwitchTo().Frame(driver.FindElement(By.Id("contentIFrame0")));
            driver.FindElement(By.CssSelector("input#crmGrid_findCriteria")).SendKeys(UserEmailAddress);
            //driver.FindElement(By.CssSelector("input#crmGrid_findCriteria")).SendKeys("AutoNonMemberXs1qg@yopmail.com");
            Thread.Sleep(3000);
            driver.FindElement(By.CssSelector("input#crmGrid_findCriteria")).SendKeys(Keys.Enter);


        }
        public void verifyFirstNameLastNameInSilverbear()
        {

            Thread.Sleep(20000);
            driver.SwitchTo().DefaultContent();
            //iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(SearchGrid));
            //int recordCount = driver.FindElement(SearchGrid).FindElements(By.TagName("tr")).Count;
            Thread.Sleep(4000);

            driver.SwitchTo().Frame(driver.FindElement(frame0));
            //driver.FindElement(By.CssSelector("table#gridBodyTable>tbody>tr>td")).Click();
            IWebElement ele_SearchTable = driver.FindElement(searchGrid);
            //String Message = driver.FindElement(By.XPath("//*[@id='gridBodyTable']/tbody/tr[2]/td")).Text;
            int recordCount = driver.FindElement(searchGrid).FindElements(By.TagName("tr")).Count;
            if (recordCount == 1)
            {

                IWebElement ele_firstRecord = ele_SearchTable.FindElements(By.TagName("tr")).ElementAt(0);  // Get the first record from search table

                iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(driver.FindElement(searchGrid).FindElement(By.CssSelector("td:nth-child(2)"))));

                Thread.Sleep(5000);

                ele_firstRecord.FindElement(By.CssSelector("td:nth-child(2)")).Click();

                Thread.Sleep(5000);

                //ele_firstRecord.FindElement(By.CssSelector("td:nth-child(2)")).Click();

                //iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(loadingSB));

                //driver.SwitchTo().Frame(driver.FindElement(By.Id("contentIFrame1")));

                driver.SwitchTo().DefaultContent();

                //iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(newContactHeader));

                Thread.Sleep(5000);

                driver.SwitchTo().DefaultContent();

                driver.SwitchTo().Frame(driver.FindElement(frame1));

                String FirstName = driver.FindElement(firstName).Text;
                String LastName = driver.FindElement(lastName).Text;

                forename.Equals(FirstName, StringComparison.CurrentCultureIgnoreCase);
                surname.Equals(LastName, StringComparison.CurrentCultureIgnoreCase);

                //Assert.AreEqual(forename, FirstName);
                //Assert.AreEqual(surname, LastName);




                //driver.FindElement(SearchGrid).FindElements(By.TagName("tr")).ElementAt(0).FindElement(By.CssSelector("td:nth-child(2)")).Click();

                Thread.Sleep(5000);


            }
        }

        public void verifyFirstNameLastNameInSilverbearforMemberUser()
        {

            Thread.Sleep(20000);
            driver.SwitchTo().DefaultContent();
            //iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementExists(SearchGrid));
            //int recordCount = driver.FindElement(SearchGrid).FindElements(By.TagName("tr")).Count;
            Thread.Sleep(4000);

            driver.SwitchTo().Frame(driver.FindElement(frame0));
            //driver.FindElement(By.CssSelector("table#gridBodyTable>tbody>tr>td")).Click();
            IWebElement ele_SearchTable = driver.FindElement(searchGrid);
            //String Message = driver.FindElement(By.XPath("//*[@id='gridBodyTable']/tbody/tr[2]/td")).Text;
            int recordCount = driver.FindElement(searchGrid).FindElements(By.TagName("tr")).Count;
            if (recordCount == 1)
            {

                IWebElement ele_firstRecord = ele_SearchTable.FindElements(By.TagName("tr")).ElementAt(0);  // Get the first record from search table

                iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(driver.FindElement(searchGrid).FindElement(By.CssSelector("td:nth-child(2)"))));

                Thread.Sleep(5000);

                ele_firstRecord.FindElement(By.CssSelector("td:nth-child(2)")).Click();

                Thread.Sleep(5000);

                //ele_firstRecord.FindElement(By.CssSelector("td:nth-child(2)")).Click();

                //iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.InvisibilityOfElementLocated(loadingSB));

                //driver.SwitchTo().Frame(driver.FindElement(By.Id("contentIFrame1")));

                driver.SwitchTo().DefaultContent();

                //iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(newContactHeader));

                Thread.Sleep(5000);

                driver.SwitchTo().DefaultContent();

                driver.SwitchTo().Frame(driver.FindElement(frame1));

                String FirstName = driver.FindElement(firstNameLbl).Text;
                String LastName = driver.FindElement(lastNameLbl).Text;

                //string firstName = Objects.objMemberPO.enterFirstName();
                //string lastName = Objects.objMemberPO.enterLastName();

                //firstName.Equals(FirstName, StringComparison.CurrentCultureIgnoreCase);
                //lastName.Equals(LastName, StringComparison.CurrentCultureIgnoreCase);

                //Assert.AreEqual(forename, FirstName);
                //Assert.AreEqual(surname, LastName);




                //driver.FindElement(SearchGrid).FindElements(By.TagName("tr")).ElementAt(0).FindElement(By.CssSelector("td:nth-child(2)")).Click();

                Thread.Sleep(5000);

                driver.Quit();
                driver.Dispose();
                Thread.Sleep(2000);

            }
        }
        public void clickOnFacebookLink()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(facebookLink));
            driver.FindElement(facebookLink).Click();
        }

        public void enterEmailForFacebook()
        {
            //Helper.IsJqueryActive(driver);
            //Helper.IsJavaScriptActive(driver);
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(emailFacebookTxtbox));
            driver.FindElement(emailFacebookTxtbox).SendKeys(cf.readingXMLFile("SSO", "NonMember", "SocialUser", "Config.xml"));

        }

        public void enterPasswordForFacebook()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(passwordFacebookTxtbox));
            driver.FindElement(passwordFacebookTxtbox).SendKeys(cf.readingXMLFile("SSO", "NonMember", "Facebook-Password", "Config.xml"));
        }

        public void clickOnLoginForFacebook()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementToBeClickable(passwordFacebookTxtbox));
            driver.FindElement(loginFacebookBtn).Click();
        }

        public void verifyInvalidEmailValidationMsg()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(validationErrorMessage));
            ActualInvalidEmailValMsg = driver.FindElement(validationErrorMessage).Text;
            ExpectedInvalidEmailValMsg = cf.readingXMLFile("SSO", "Login", "ValidationMessagForResetPassword", "Config.xml");
            Assert.AreEqual(ExpectedInvalidEmailValMsg, ActualInvalidEmailValMsg);
        }

        public void verifyIncorrectVerificationCodeValidationMsg()
        {
            iWait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(validationMsgIncorrectCode));
            ActualIncorrectCodeValMsg = driver.FindElement(validationMsgIncorrectCode).Text;
            ExpectedIncorrectCodeValMsg = cf.readingXMLFile("SSO", "Login", "IncorrectVerificationCodeValidationMsg", "Config.xml");
            Assert.AreEqual(ExpectedIncorrectCodeValMsg, ActualIncorrectCodeValMsg);
        }

    }
}
